package com.abhim5yu.docvault

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val INK = Color(0xFF17140F)
val LIME = Color(0xFFC6F26B)
val PAL = listOf(Color(0xFFFFE58A), Color(0xFFD8C8FF), Color(0xFFFFB4A2), Color(0xFFD3F58C))
val TYPES = listOf("text" to "Text", "password" to "Password", "docs" to "Docs", "notes" to "Notes")
val FIELDS = mapOf(
    "text" to listOf("name", "number"),
    "password" to listOf("name", "link", "pass"),
    "docs" to listOf("name", "notes"),
    "notes" to listOf("body")
)
fun label(t: String) = TYPES.firstOrNull { it.first == t }?.second ?: "Text"

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { App() }
    }
}

@Composable
fun DVTheme(content: @Composable () -> Unit) {
    val scheme = if (isSystemInDarkTheme()) darkColorScheme(
        primary = LIME, onPrimary = INK, background = Color(0xFF16130F), onBackground = Color(0xFFF6F0E4),
        surface = Color(0xFF211D17), onSurface = Color(0xFFF6F0E4),
        surfaceVariant = Color(0xFF2A251D), onSurfaceVariant = Color(0xFFA89F8E)
    ) else lightColorScheme(
        primary = LIME, onPrimary = INK, background = Color(0xFFFAF5EA), onBackground = INK,
        surface = Color(0xFFFFFDF8), onSurface = INK,
        surfaceVariant = Color(0xFFF1E9D6), onSurfaceVariant = Color(0xFF6F675A)
    )
    MaterialTheme(colorScheme = scheme, content = content)
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("dv", 0) }
    var recs by remember { mutableStateOf(Store.load(ctx)) }
    var tab by remember { mutableIntStateOf(0) }
    var hide by remember { mutableStateOf(prefs.getBoolean("hide", false)) }
    var editing by remember { mutableStateOf<Rec?>(null) }
    fun commit(l: List<Rec>) { recs = l; Store.save(ctx, l) }

    DVTheme {
        Scaffold(
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                    listOf("➕" to "Add", "📁" to "Saved", "⚙️" to "Settings").forEachIndexed { i, (ic, lb) ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Text(ic, fontSize = 20.sp) },
                            label = { Text(lb, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                indicatorColor = LIME, selectedTextColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                }
            }
        ) { pad ->
            Box(Modifier.padding(pad)) {
                when (tab) {
                    0 -> AddScreen(
                        recs, editing,
                        onSave = { r ->
                            commit(if (recs.any { it.id == r.id }) recs.map { if (it.id == r.id) r else it } else recs + r)
                            editing = null; tab = 1
                            Toast.makeText(ctx, "Saved", Toast.LENGTH_SHORT).show()
                        },
                        onCancel = { editing = null; tab = 1 }
                    )
                    1 -> SavedScreen(
                        recs, hide,
                        onPin = { r -> commit(recs.map { if (it.id == r.id) it.copy(pinned = !it.pinned) else it }) },
                        onEdit = { editing = it; tab = 0 },
                        onDelete = { r -> commit(recs.filter { it.id != r.id }) }
                    )
                    else -> SettingsScreen(
                        hide, { hide = it; prefs.edit().putBoolean("hide", it).apply() },
                        recs.size, { commit(emptyList()) }
                    )
                }
            }
        }
    }
}

@Composable
fun Tile(m: Modifier, bg: Color, title: String, value: String, size: Int) {
    Column(
        m.clip(RoundedCornerShape(28.dp)).background(bg).padding(16.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, fontSize = 12.sp, fontWeight = FontWeight.ExtraBold, color = INK.copy(alpha = .65f), letterSpacing = 1.sp)
        Text(value, fontSize = size.sp, fontWeight = FontWeight.ExtraBold, color = INK)
    }
}

@Composable
fun Field(v: String, on: (String) -> Unit, hint: String, mono: Boolean = false, secret: Boolean = false, lines: Int = 1) {
    var show by remember { mutableStateOf(false) }
    OutlinedTextField(
        value = v, onValueChange = on, label = { Text(hint) },
        modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(18.dp),
        singleLine = lines == 1, minLines = lines,
        textStyle = TextStyle(fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default, fontSize = 16.sp),
        visualTransformation = if (secret && !show) PasswordVisualTransformation() else VisualTransformation.None,
        trailingIcon = if (secret) {
            { Text(if (show) "Hide" else "Show", Modifier.clickable { show = !show }.padding(12.dp), fontWeight = FontWeight.Bold, fontSize = 13.sp) }
        } else null
    )
}

@Composable
fun AddScreen(recs: List<Rec>, editing: Rec?, onSave: (Rec) -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    var type by remember(editing) { mutableStateOf(editing?.type ?: "text") }
    var name by remember(editing) { mutableStateOf(editing?.name ?: "") }
    var number by remember(editing) { mutableStateOf(editing?.number ?: "") }
    var link by remember(editing) { mutableStateOf(editing?.link ?: "") }
    var pass by remember(editing) { mutableStateOf(editing?.password ?: "") }
    var body by remember(editing) { mutableStateOf(editing?.body ?: "") }
    val show = FIELDS.getValue(type)
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(if (editing == null) "DocVault" else "Edit card", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        if (editing == null) {
            Row(Modifier.fillMaxWidth().height(190.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Tile(Modifier.weight(1.1f).fillMaxHeight(), LIME, "TOTAL", "${recs.size}", 72)
                Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Tile(Modifier.weight(1f).fillMaxWidth(), PAL[0], "PINNED", "${recs.count { it.pinned }}", 28)
                    Tile(Modifier.weight(1f).fillMaxWidth(), PAL[1], "PASSWORDS", "${recs.count { it.type == "password" }}", 28)
                }
            }
        }
        Surface(shape = RoundedCornerShape(32.dp), color = MaterialTheme.colorScheme.surface, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TYPES.forEachIndexed { i, t ->
                        val on = type == t.first
                        Box(
                            Modifier.weight(1f).height(40.dp).clip(RoundedCornerShape(16.dp))
                                .background(if (on) PAL[i] else MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { type = t.first },
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                t.second, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1,
                                color = if (on) INK else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                if ("name" in show) Field(name, { name = it }, "Name")
                if ("number" in show) Field(number, { number = it }, "Number", mono = true)
                if ("link" in show) Field(link, { link = it }, "Link or account email")
                if ("pass" in show) Field(pass, { pass = it }, "Password", mono = true, secret = true)
                if ("notes" in show) Field(body, { body = it }, "Notes", lines = 3)
                if ("body" in show) Field(body, { body = it }, "Write your note…", lines = 7)
                Button(
                    onClick = {
                        val b = if ("body" in show || "notes" in show) body.trim() else ""
                        val nm = if (type == "notes") b.lineSequence().first().take(40) else name.trim()
                        val nu = if ("number" in show) number.trim() else ""
                        val li = if ("link" in show) link.trim() else ""
                        val pw = if ("pass" in show) pass else ""
                        if (nm.isEmpty() && nu.isEmpty() && li.isEmpty() && pw.isEmpty() && b.isEmpty()) {
                            Toast.makeText(ctx, "Please enter some details", Toast.LENGTH_SHORT).show()
                        } else {
                            onSave(
                                Rec(
                                    editing?.id ?: "r${System.currentTimeMillis()}", type, nm.ifEmpty { "Untitled" },
                                    nu, li, pw, b, editing?.color ?: (recs.size % 4), editing?.pinned ?: false
                                )
                            )
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(20.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = LIME, contentColor = INK)
                ) { Text(if (editing == null) "Add" else "Save changes", fontWeight = FontWeight.ExtraBold, fontSize = 15.sp) }
                if (editing != null) TextButton(onClick = onCancel, modifier = Modifier.fillMaxWidth()) { Text("Cancel") }
            }
        }
    }
}

@Composable
fun SavedScreen(recs: List<Rec>, hide: Boolean, onPin: (Rec) -> Unit, onEdit: (Rec) -> Unit, onDelete: (Rec) -> Unit) {
    var q by remember { mutableStateOf("") }
    var f by remember { mutableStateOf("all") }
    var del by remember { mutableStateOf<Rec?>(null) }
    val terms = q.trim().lowercase().split(Regex("\\s+")).filter { it.isNotEmpty() }
    val shown = recs.filter { r ->
        val hay = listOf(r.name, r.number, r.link, r.body, r.password, label(r.type)).joinToString("\n").lowercase()
        (f == "all" || r.type == f) && terms.all { hay.contains(it) }
    }.sortedWith(compareByDescending<Rec> { it.pinned }.thenByDescending { it.id })
    val opts = listOf("all" to "All") + TYPES
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Saved", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, modifier = Modifier.padding(top = 16.dp))
        OutlinedTextField(
            value = q, onValueChange = { q = it }, placeholder = { Text("Search anything…") },
            singleLine = true, shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth()
        )
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(opts) { o ->
                val on = f == o.first
                Box(
                    Modifier.height(40.dp).clip(RoundedCornerShape(16.dp))
                        .background(if (on) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.surface)
                        .clickable { f = o.first }.padding(horizontal = 18.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        o.second, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold,
                        color = if (on) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
        if (shown.isEmpty()) {
            Text(
                if (recs.isEmpty()) "Nothing saved yet. Add your first card from the Add tab." else "No matches.",
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 24.dp)
            )
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp), contentPadding = PaddingValues(bottom = 16.dp)) {
            items(shown, key = { it.id }) { r -> CardView(r, hide, { onPin(r) }, { onEdit(r) }, { del = r }) }
        }
    }
    del?.let { d ->
        AlertDialog(
            onDismissRequest = { del = null },
            confirmButton = { TextButton(onClick = { onDelete(d); del = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("Cancel") } },
            title = { Text("Delete \"${d.name}\"?") }, text = { Text("This can't be undone.") }
        )
    }
}

@Composable
fun Line(value: String, mono: Boolean = false, extra: String? = null, onExtra: () -> Unit = {}, lines: Int = 3, onCopy: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color.White.copy(alpha = .6f))
            .padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            value, Modifier.weight(1f), color = INK, fontSize = 15.sp, fontWeight = FontWeight.Bold, maxLines = lines,
            fontFamily = if (mono) FontFamily.Monospace else FontFamily.Default
        )
        if (extra != null) Text(extra, Modifier.clickable { onExtra() }.padding(8.dp), color = INK, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
        Text("Copy", Modifier.clickable { onCopy() }.padding(8.dp), color = INK, fontSize = 13.sp, fontWeight = FontWeight.ExtraBold)
    }
}

@Composable
fun CardView(r: Rec, hide: Boolean, onPin: () -> Unit, onEdit: () -> Unit, onDel: () -> Unit) {
    val ctx = LocalContext.current
    val cm = LocalClipboardManager.current
    var reveal by remember { mutableStateOf(false) }
    fun copy(v: String) { cm.setText(AnnotatedString(v)); Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show() }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp)).background(PAL[r.color % 4]).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.name, fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, color = INK)
                Text(label(r.type), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = INK.copy(alpha = .65f))
            }
            Text(if (r.pinned) "⭐" else "☆", Modifier.clickable { onPin() }.padding(8.dp), fontSize = 20.sp, color = INK)
            Text("✏️", Modifier.clickable { onEdit() }.padding(8.dp), fontSize = 18.sp)
            Text("🗑️", Modifier.clickable { onDel() }.padding(8.dp), fontSize = 18.sp)
        }
        if (r.number.isNotEmpty()) Line(if (hide) "••••" else r.number, mono = true) { copy(r.number) }
        if (r.link.isNotEmpty()) Line(r.link) { copy(r.link) }
        if (r.password.isNotEmpty()) Line(
            if (hide || !reveal) "••••••••" else r.password, mono = true,
            extra = if (hide) null else if (reveal) "Hide" else "Show", onExtra = { reveal = !reveal }
        ) { copy(r.password) }
        if (r.body.isNotEmpty()) Line(if (hide) "••••" else r.body, lines = 50) { copy(r.body) }
    }
}

@Composable
fun SettingsScreen(hide: Boolean, onHide: (Boolean) -> Unit, count: Int, onClear: () -> Unit) {
    var ask by remember { mutableStateOf(false) }
    val surface = MaterialTheme.colorScheme.surface
    val mute = MaterialTheme.colorScheme.onSurfaceVariant
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Settings", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
        Surface(shape = RoundedCornerShape(28.dp), color = surface, modifier = Modifier.fillMaxWidth()) {
            Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Hide sensitive text", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    Text("Masks numbers, passwords and notes on cards", fontSize = 13.sp, color = mute)
                }
                Switch(checked = hide, onCheckedChange = onHide, colors = SwitchDefaults.colors(checkedTrackColor = LIME, checkedThumbColor = INK))
            }
        }
        Surface(shape = RoundedCornerShape(28.dp), color = surface, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Encrypted storage", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                Text("Your $count cards are saved encrypted (AES-256) with a key held by the Android Keystore. The app has no internet permission, so nothing leaves this phone.", fontSize = 13.sp, color = mute)
            }
        }
        Button(
            onClick = { ask = true }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(20.dp),
            colors = ButtonDefaults.buttonColors(containerColor = PAL[2], contentColor = INK)
        ) { Text("Delete all cards", fontWeight = FontWeight.ExtraBold) }
    }
    if (ask) AlertDialog(
        onDismissRequest = { ask = false },
        confirmButton = { TextButton(onClick = { onClear(); ask = false }) { Text("Delete everything") } },
        dismissButton = { TextButton(onClick = { ask = false }) { Text("Cancel") } },
        title = { Text("Delete all cards?") }, text = { Text("This can't be undone.") }
    )
}
