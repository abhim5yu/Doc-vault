package com.abhim5yu.docvault

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

data class Rec(
    val id: String, val type: String, val name: String = "", val number: String = "",
    val link: String = "", val password: String = "", val body: String = "",
    val color: Int = 0, val pinned: Boolean = false
)

/** Cards are saved as one AES-256-GCM encrypted file; the key lives in the Android Keystore. */
object Store {
    private const val ALIAS = "docvault_key"

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        g.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256).build()
        )
        return g.generateKey()
    }

    fun save(c: Context, list: List<Rec>) {
        val arr = JSONArray()
        list.forEach { r ->
            arr.put(
                JSONObject().put("id", r.id).put("type", r.type).put("name", r.name).put("number", r.number)
                    .put("link", r.link).put("password", r.password).put("body", r.body)
                    .put("color", r.color).put("pinned", r.pinned)
            )
        }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        val out = cipher.iv + cipher.doFinal(arr.toString().toByteArray())
        val tmp = File(c.filesDir, "vault.tmp")
        tmp.writeBytes(out)
        tmp.renameTo(File(c.filesDir, "vault.bin"))
    }

    fun load(c: Context): List<Rec> {
        val f = File(c.filesDir, "vault.bin")
        if (!f.exists()) return emptyList()
        return try {
            val b = f.readBytes()
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                .apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, b.copyOfRange(0, 12))) }
            val arr = JSONArray(String(cipher.doFinal(b, 12, b.size - 12)))
            List(arr.length()) { i ->
                val o = arr.getJSONObject(i)
                Rec(
                    o.getString("id"), o.getString("type"), o.optString("name"), o.optString("number"),
                    o.optString("link"), o.optString("password"), o.optString("body"),
                    o.optInt("color"), o.optBoolean("pinned")
                )
            }
        } catch (e: Exception) { emptyList() }
    }
}
